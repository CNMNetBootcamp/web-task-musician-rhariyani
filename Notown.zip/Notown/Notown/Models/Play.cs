﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Notown.Models
{
    public class Play
    {
        public int ID { get; set; }
        public int InstrumentID { get; set; }
        public int MusicianID { get; set; }

        public Musician Musician { get; set; }
        public Instrument Instrument { get; set; }




    }
}

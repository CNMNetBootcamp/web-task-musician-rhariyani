﻿//using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Notown.Models
{
    public class Place
    {
        public int ID { get; set; }
        [Required]
        public string Address { get; set; }

        [Required]
        public int TelephoneNumber { get; set; }

        public ICollection<Musician> Musicians { get; set; }
    }
}

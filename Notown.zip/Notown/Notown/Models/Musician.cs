﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Notown.Models
{
    public class Musician
    {
        public int ID { get; set; }
        [Required]
        public string SSN { get; set; }
        [Required]
        public string MName { get; set; }
       

        // Foreign Keys
       
        public int PlaceID { get; set; }
       

        public Place Place { get; set; }


        public Play Plays { get; set; }
        public Perform Performens { get; set; }

        public ICollection<Album> Albums { get; set; }
        public ICollection<Song> Songs { get; set; }

    }
}

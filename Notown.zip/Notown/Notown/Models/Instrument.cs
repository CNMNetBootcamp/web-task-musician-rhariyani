﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Rewrite.Internal.ApacheModRewrite;

namespace Notown.Models
{
    public class Instrument
    {
        public int ID { get; set; }

        [Required]

        public string Name { get; set; }

        [Required]

        public string MusicKey { get; set; }

        public Play Players { get; set; }



    }
}

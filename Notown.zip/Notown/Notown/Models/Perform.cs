﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Notown.Models
{
    public class Perform
    {
        public int ID { get; set; }
        public int SongID { get; set; }
        public int MusicianID { get; set; }

        public Musician Musician { get; set; }
        public Song Song { get; set; }


    }
}

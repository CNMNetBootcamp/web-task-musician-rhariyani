﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Notown.Models
{
    public class Album
    {

        public int ID { get; set; }

        [Required]
        public string Tittle { get; set; }
        [Required]
        public string Format { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Copyright Date")]
        public DateTime CopyrightDate { get; set; }

        [Required]
        public string AlbumIdentifier { get; set; }

        public Musician Musician { get; set; }
        public Song Song { get; set; }

    }  
}

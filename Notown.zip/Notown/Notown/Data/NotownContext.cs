﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Notown.Models;

namespace Notown.Data
{
    public class NotownContext : DbContext
    {
        public NotownContext(DbContextOptions<NotownContext> options)
            : base(options)
        {
        }

        public DbSet<Album> Album { get; set; }
        public DbSet<Instrument> Instrument { get; set; }
        public DbSet<Musician> Musician { get; set; }
        public DbSet<Place> Place { get; set; }
        public DbSet<Song> Song { get; set; }
        public DbSet<Play> Play { get; set; }
        public DbSet<Perform> Perform { get; set; }

        internal static Task<string> ToListAsync()
        {
            throw new NotImplementedException();
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);



            builder.Entity<Album>().ToTable("Album");
            builder.Entity<Instrument>().ToTable("Instrument");
            builder.Entity<Musician>().ToTable("Musician");
            builder.Entity<Place>().ToTable("Place");
            builder.Entity<Song>().ToTable("Song");
            builder.Entity<Play>().ToTable("Play");
            builder.Entity<Perform>().ToTable("Perform");



            // Add an index so that the SSN is a unique value.
            builder.Entity<Musician>()
                .HasIndex(s => s.SSN)
                .IsUnique();

        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Rewrite.Internal.ApacheModRewrite;
using Notown.Models;

namespace Notown.Data
{
    public class DbInitializer
    {
        public static void Initialize(NotownContext context)
        {
            context.Database.EnsureCreated();

            // Don't seed if already seeded.
            if (context.Musician.Any())
            {
                return;
            }
            //delete first ask questions later
            if (context.Musician.Any())
            {
                foreach (var musician in context.Musician)
                {
                    context.Musician.Remove(musician);
                }
                context.SaveChanges();
                AddMusician(context);
            }
            else
            {
                AddMusician(context);
            }
            if (context.Album.Any())
            {
                //start
                foreach (var album in context.Album)
                {

                    context.Album.Remove(album);
                }
                context.SaveChanges();
                AddAlbum(context);
                //end
            }

            else
            {
                AddAlbum(context);
            }


            if (context.Instrument.Any())
            {
                //start
                foreach (var inst in context.Instrument)
                {
                    context.Instrument.Remove(inst);
                }
                AddInsturment(context);
            }
            else
            {
                AddInsturment(context);
            }
            if (context.Song.Any())
            {
                foreach (var song in context.Song)
                {
                    context.Song.Remove(song);
                }
                context.SaveChanges();
                AddSong(context);
            }
            else
            {
                AddSong(context);
            }
            if (context.Place.Any())
            {
                foreach (var place in context.Place)
                {
                    context.Place.Remove(place);
                }
                context.SaveChanges();
                AddPlace(context);
            }
            else
            {
                AddPlace(context);
            }
            if (context.Instrument.Any())
            {
                //start
                foreach (var inst in context.Instrument)
                {
                    context.Instrument.Remove(inst);
                }
                AddInsturment(context);
            }
            else
            {
                AddInsturment(context);
            }
            if (context.Play.Any())
            {
                foreach (var play in context.Play)
                {
                    context.Play.Remove(play);
                }
                context.SaveChanges();
                AddPlay(context);
            }
            else
            {
                AddPlay(context);
            }

            if (context.Instrument.Any())
            {
                //start
                foreach (var inst in context.Instrument)
                {
                    context.Instrument.Remove(inst);
                }
                AddInsturment(context);
            }
            else
            {
                AddInsturment(context);
            }
            if (context.Perform.Any())
            {
                foreach (var perf in context.Perform)
                {
                    context.Perform.Remove(perf);
                }
                context.SaveChanges();
                AddPerform(context);
            }
            else
            {
                AddPerform(context);
            }
        }
            private static void AddPlace(NotownContext context)
            {

                var places = new Place[]
                {
                new Place
                {
                    Address = "73 vista Street",
                    TelephoneNumber = 55662288
                },
                new Place
                {
                    Address = "456 snadia Avenue",
                    TelephoneNumber = 33225588
                },
                new Place
                {
                    Address = "1722 East montoya Road",
                    TelephoneNumber = 38506421
                }
             };
                foreach (var place in places)
                {
                    context.Place.Add(place);
                }

                context.SaveChanges();

            }
        

        private static void AddInsturment(NotownContext context)
        {
            var instruments = new Instrument[]
        {
                new Instrument
                {
                    MusicKey = "C",
                    Name = "Piano"
                },
                new Instrument
                {
                    MusicKey = "D",
                    Name = "Guitar"
                },
                new Instrument
                {
                    MusicKey = "B-flat",
                    Name = "Drum"
                }
        };

            foreach (var instrument in instruments)
            {
                context.Instrument.Add(instrument);
            }

            context.SaveChanges();
        }

        private static void AddMusician(NotownContext context)
        {
            var musicians = new Musician[]
        {
                new Musician
                {
                    SSN = "123456789",
                    MName = "Lilly",
                    PlaceID = 1
                },
                new Musician
                {
                    SSN = "876543211",
                    MName = "Mona",
                    PlaceID = 2
                },
                new Musician
                {
                    SSN = "113456882",
                    MName = "James",
                    PlaceID = 3
                }
        };

            foreach (var musician in musicians)
            {
                context.Musician.Add(musician);
            }

            context.SaveChanges();
        }
        private static void AddAlbum(NotownContext context)
        {

            var albums = new Album[]
            {
                new Album
                {
                    Tittle = "Roo Roo ",
                    CopyrightDate = DateTime.Parse("2006-09-01"),
                    Format = "CD",
                    AlbumIdentifier="A"
                },
                new Album
                {
                    Tittle = "Baby",
                    CopyrightDate = DateTime.Parse("2016-10-23"),
                    Format = "MC",
                    AlbumIdentifier="B"
                },
                new Album
                {
                    Tittle = "Wheels",
                    CopyrightDate = DateTime.Parse("2016-11-23"),
                    Format = "MC",
                    AlbumIdentifier="c"
                }
            };

            foreach (var album in albums)
            {
                context.Album.Add(album);
            }

            context.SaveChanges();
        }
        private static void AddSong(NotownContext context)
        {
            var songs = new Song[]
            {
                new Song
                {
                    Title = "Yellow Banana",
                    Author="Gomz",

                },
                new Song
                {
                    Title = "ding ding ",
                    Author="Road"

                },
                new Song
                {
                    Title = "Taki Taki",
                    Author="Dj snake"

                },
                new Song
                {
                    Title = "Love me like ",
                     Author="50 sheds "


                },
                new Song
                {
                    Title = "What is Love? ",
                    Author="reyon"
                }
    };

            foreach (var song in songs)
            {
                context.Song.Add(song);
            }

            context.SaveChanges();
        }
        private static void AddPlay(NotownContext context)
        {

            var play = new Play[]
            {
                new Play
                {
                     InstrumentID  = 2,
                    MusicianID = 2
                },
                new Play
                {
                     InstrumentID  = 1,
                    MusicianID = 1
                },
                new Play
                {
                    InstrumentID  = 2,
                    MusicianID = 2
                }
         };
            foreach (var p in play)
            {
                context.Play.Add(p);
            }

            context.SaveChanges();

        }
        private static void AddPerform(NotownContext context)
        {

            var perf = new Perform[]
            {
                new Perform
                {
                     SongID  = 2,
                    MusicianID = 2
                },
                new Perform
                {
                     SongID  = 3,
                    MusicianID = 3
                },
                new Perform
                {
                    SongID  = 1,
                    MusicianID = 1
                }
         };
            foreach (var per in perf)
            {
                context.Perform.Add(per);
            }

            context.SaveChanges();


        }
    }
}

    
    


